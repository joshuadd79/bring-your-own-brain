export type GameState = 'idle' | 'rolling' | 'evaluating' | 'speaking' | 'ghost_panic' | 'round_end';

export type AIEmotion = 'normal' | 'smug' | 'salty' | 'terrified' | 'rolling' | 'victorious';

export interface AIProfile {
  id: 'reginald' | 'grunk';
  name: string;
  title: string;
  avatar: string;
  themeColor: string;
  accentColor: string;
  borderColor: string;
  systemPrompt: string;
  offlineQuotes: string[];
  ghostQuotes: string[];
  totalScore: number;
  matchWins: number;
  currentRoll: number[];
  lastCombo: string;
  lastPoints: number;
  isRolling: boolean;
  emotion: AIEmotion;
}

export interface DiceScoreResult {
  dice: number[];
  comboName: string;
  category: 'five_kind' | 'four_kind' | 'full_house' | 'straight' | 'three_kind' | 'two_pair' | 'one_pair' | 'high_sum' | 'snake_eyes' | 'boxcars';
  score: number;
  description: string;
  flavor: string;
}

export interface ChatMessage {
  id: string;
  sender: 'reginald' | 'grunk' | 'ghost' | 'narrator';
  senderName: string;
  content: string;
  isStreaming?: boolean;
  timestamp: number;
  flavorTag?: string;
  diceSummary?: string;
}

export interface GameSettings {
  turnDelayMs: number; // 2500, 4000, 6000
  soundEnabled: boolean;
  targetScore: number;
  temperature: number;
  allowOfflineFallback: boolean;
}

export interface BYOBStateInfo {
  status: 'disconnected' | 'connecting' | 'connected' | 'error';
  modelName?: string;
  info?: string;
}
