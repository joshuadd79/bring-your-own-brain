import React, { useState } from 'react';
import { Ghost, Send, Sparkles, Skull, HelpCircle } from 'lucide-react';
import { GHOST_QUICK_PHRASES } from '../utils/personalityDefaults';

interface GhostIntercomProps {
  onSendGhostMessage: (message: string) => void;
  disabled: boolean;
}

export const GhostIntercom: React.FC<GhostIntercomProps> = ({
  onSendGhostMessage,
  disabled,
}) => {
  const [inputVal, setInputVal] = useState('');
  const [showQuickPhrases, setShowQuickPhrases] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = inputVal.trim();
    if (!trimmed || disabled) return;
    onSendGhostMessage(trimmed);
    setInputVal('');
  };

  const handleSelectQuick = (phrase: string) => {
    if (disabled) return;
    onSendGhostMessage(phrase);
    setShowQuickPhrases(false);
  };

  return (
    <div className="relative rounded-2xl bg-gradient-to-r from-slate-950 via-cyan-950/40 to-slate-950 border border-cyan-800/40 p-3 sm:p-4 shadow-xl">
      {/* Ghost Header */}
      <div className="flex items-center justify-between gap-2 mb-2">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
            <Ghost className="w-4 h-4 animate-bounce" />
          </div>
          <div>
            <span className="text-xs sm:text-sm font-cinzel font-bold text-cyan-200 tracking-wide flex items-center gap-1.5">
              THE SPECTRAL INTERCOM
              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-cyan-900/60 text-cyan-300 border border-cyan-600/40">
                GHOST VOICE
              </span>
            </span>
            <p className="text-[11px] text-zinc-400">
              Speak into the tavern from beyond the veil. To them, you are an eerie poltergeist!
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setShowQuickPhrases(!showQuickPhrases)}
          className="text-xs flex items-center gap-1 text-cyan-300 hover:text-cyan-100 bg-cyan-950/60 hover:bg-cyan-900/80 px-2.5 py-1 rounded-lg border border-cyan-700/50 transition-colors"
        >
          <Sparkles className="w-3 h-3" />
          <span className="hidden sm:inline">Ghost Spells</span>
          <span className="sm:hidden">Spells</span>
        </button>
      </div>

      {/* Quick Phrases Drawer */}
      {showQuickPhrases && (
        <div className="mb-3 p-2.5 rounded-xl bg-zinc-950/90 border border-cyan-700/30 grid grid-cols-1 sm:grid-cols-2 gap-1.5 animate-in fade-in duration-200">
          <div className="col-span-full text-[10px] uppercase font-mono text-cyan-400 flex items-center justify-between">
            <span>Tap to possess the room:</span>
            <button
              onClick={() => setShowQuickPhrases(false)}
              className="text-zinc-500 hover:text-zinc-300"
            >
              ✕
            </button>
          </div>
          {GHOST_QUICK_PHRASES.map((phrase, idx) => (
            <button
              key={idx}
              type="button"
              disabled={disabled}
              onClick={() => handleSelectQuick(phrase)}
              className="text-left text-xs text-cyan-200 hover:text-white bg-cyan-950/40 hover:bg-cyan-900/60 p-2 rounded-lg border border-cyan-900/40 transition-all truncate disabled:opacity-50"
            >
              👻 "{phrase}"
            </button>
          ))}
        </div>
      )}

      {/* Input Form */}
      <form onSubmit={handleSubmit} className="flex items-center gap-2">
        <div className="relative flex-1">
          <input
            type="text"
            value={inputVal}
            onChange={(e) => setInputVal(e.target.value)}
            disabled={disabled}
            placeholder={disabled ? 'Waiting for current roll...' : 'Whisper something spooky... (e.g. "Grunk, I stole your dice!")'}
            className="w-full bg-zinc-900/90 text-sm text-cyan-100 placeholder-zinc-500 rounded-xl px-3.5 py-2.5 pl-9 border border-cyan-700/50 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 disabled:opacity-50 transition-all font-sans"
            maxLength={180}
          />
          <Skull className="w-4 h-4 text-cyan-400/70 absolute left-3 top-3 pointer-events-none" />
        </div>

        <button
          type="submit"
          disabled={!inputVal.trim() || disabled}
          className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl font-cinzel font-bold text-xs bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white shadow-lg shadow-cyan-900/30 disabled:opacity-40 disabled:cursor-not-allowed transition-all active:scale-95"
        >
          <Send className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">HAUNT</span>
        </button>
      </form>
    </div>
  );
};
