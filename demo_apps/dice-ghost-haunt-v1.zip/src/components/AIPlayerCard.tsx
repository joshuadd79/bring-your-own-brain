import React from 'react';
import { AIProfile } from '../types/game';
import { Dice3D } from './Dice3D';
import { Trophy, Flame, Skull, Ghost, Sparkles, Volume2 } from 'lucide-react';

interface AIPlayerCardProps {
  profile: AIProfile;
  isCurrentTurn: boolean;
  speechText: string;
  isStreaming: boolean;
  scoreLeader: boolean;
}

export const AIPlayerCard: React.FC<AIPlayerCardProps> = ({
  profile,
  isCurrentTurn,
  speechText,
  isStreaming,
  scoreLeader,
}) => {
  const isReginald = profile.id === 'reginald';

  // Render SVG avatar with dynamic expressions according to emotion
  const renderAvatar = () => {
    const isPanic = profile.emotion === 'terrified';
    const isSmug = profile.emotion === 'smug';
    const isSalty = profile.emotion === 'salty';

    if (isReginald) {
      return (
        <div className={`relative w-20 h-20 sm:w-24 sm:h-24 rounded-2xl overflow-hidden border-2 transition-all duration-300 ${
          isPanic
            ? 'border-cyan-400 poltergeist-shake shadow-cyan-500/50 shadow-lg'
            : isCurrentTurn
            ? 'border-amber-400 shadow-amber-500/40 shadow-lg scale-105'
            : 'border-amber-900/40 opacity-90'
        } bg-gradient-to-b from-purple-950 via-slate-900 to-amber-950/80`}>
          <svg viewBox="0 0 100 100" className="w-full h-full">
            {/* Victorian powdered wig */}
            <path d="M 20 40 Q 15 15 50 12 Q 85 15 80 40 Q 90 60 78 70 Q 75 45 50 45 Q 25 45 22 70 Q 10 60 20 40 Z" fill="#e2e8f0" />
            <path d="M 28 32 Q 50 20 72 32" stroke="#cbd5e1" strokeWidth="3" fill="none" />
            {/* Face */}
            <path d="M 30 40 Q 50 35 70 40 L 68 70 Q 50 88 32 70 Z" fill={isPanic ? "#cffafe" : "#fed7aa"} />
            {/* Monocle on right eye */}
            <circle cx="62" cy="54" r="8" fill="none" stroke="#f59e0b" strokeWidth="2.5" />
            <line x1="68" y1="60" x2="78" y2="76" stroke="#f59e0b" strokeWidth="1.5" />
            {/* Eyes */}
            {isPanic ? (
              <>
                <circle cx="40" cy="54" r="5.5" fill="#ffffff" />
                <circle cx="40" cy="54" r="2.5" fill="#0284c7" />
                <circle cx="62" cy="54" r="6" fill="#ffffff" />
                <circle cx="62" cy="54" r="2.5" fill="#0284c7" />
                <path d="M 25 48 Q 23 54 26 55 Q 29 54 27 48 Z" fill="#38bdf8" />
              </>
            ) : isSmug ? (
              <>
                <path d="M 35 53 Q 40 50 45 53" stroke="#78350f" strokeWidth="3" fill="none" />
                <path d="M 57 53 Q 62 50 67 53" stroke="#78350f" strokeWidth="3" fill="none" />
              </>
            ) : isSalty ? (
              <>
                <line x1="33" y1="48" x2="45" y2="52" stroke="#451a03" strokeWidth="3" />
                <line x1="67" y1="48" x2="55" y2="52" stroke="#451a03" strokeWidth="3" />
                <circle cx="39" cy="54" r="2.5" fill="#451a03" />
                <circle cx="61" cy="54" r="2.5" fill="#451a03" />
              </>
            ) : (
              <>
                <circle cx="39" cy="54" r="2.5" fill="#451a03" />
                <circle cx="62" cy="54" r="2.5" fill="#451a03" />
                <path d="M 33 49 Q 39 46 45 49" stroke="#78350f" strokeWidth="2" fill="none" />
              </>
            )}
            {/* Mustache & mouth */}
            {isPanic ? (
              <path d="M 43 72 Q 50 82 57 72 Z" fill="#7f1d1d" />
            ) : isSmug ? (
              <path d="M 38 68 Q 52 74 62 66" stroke="#991b1b" strokeWidth="2.5" fill="none" />
            ) : (
              <path d="M 36 67 Q 50 64 64 67" stroke="#78350f" strokeWidth="2.5" fill="none" />
            )}
            {/* Cravat */}
            <path d="M 38 82 L 50 75 L 62 82 L 58 98 L 42 98 Z" fill="#f8fafc" />
            <path d="M 47 78 L 53 78 L 50 94 Z" fill="#e2e8f0" />
            <circle cx="50" cy="78" r="3" fill="#dc2626" />
          </svg>

          {isPanic && (
            <div className="absolute top-1 right-1 bg-cyan-500 text-slate-950 rounded-full p-1 shadow-md animate-bounce">
              <Ghost className="w-3.5 h-3.5" />
            </div>
          )}
        </div>
      );
    }

    // Grunk the goblin
    return (
      <div className={`relative w-20 h-20 sm:w-24 sm:h-24 rounded-2xl overflow-hidden border-2 transition-all duration-300 ${
        isPanic
          ? 'border-cyan-400 poltergeist-shake shadow-cyan-500/50 shadow-lg'
          : isCurrentTurn
          ? 'border-emerald-400 shadow-emerald-500/40 shadow-lg scale-105'
          : 'border-emerald-950/80 opacity-90'
      } bg-gradient-to-b from-emerald-950 via-zinc-900 to-amber-950/50`}>
        <svg viewBox="0 0 100 100" className="w-full h-full">
          {/* Big goblin ears */}
          <path d="M 28 45 Q 2 20 8 50 Q 15 65 28 58 Z" fill="#15803d" />
          <path d="M 72 45 Q 98 20 92 50 Q 85 65 72 58 Z" fill="#15803d" />
          <path d="M 25 46 Q 10 32 14 50 Z" fill="#166534" />
          <path d="M 75 46 Q 90 32 86 50 Z" fill="#166534" />
          {/* Goblin head */}
          <path d="M 26 40 Q 50 25 74 40 L 72 72 Q 50 86 28 72 Z" fill={isPanic ? "#67e8f9" : "#22c55e"} />
          <circle cx="36" cy="38" r="2.5" fill="#15803d" />
          <circle cx="68" cy="42" r="3" fill="#15803d" />
          {/* Eyes */}
          {isPanic ? (
            <>
              <circle cx="38" cy="50" r="7.5" fill="#fef08a" />
              <circle cx="38" cy="50" r="3.5" fill="#dc2626" />
              <circle cx="62" cy="50" r="7.5" fill="#fef08a" />
              <circle cx="62" cy="50" r="3.5" fill="#dc2626" />
              <path d="M 36 68 Q 50 88 64 68 Z" fill="#450a0a" />
              <rect x="42" y="68" width="5" height="6" fill="#eab308" />
              <rect x="52" y="68" width="5" height="5" fill="#f8fafc" />
            </>
          ) : isSmug ? (
            <>
              <circle cx="38" cy="49" r="4.5" fill="#fef08a" />
              <circle cx="39" cy="49" r="2" fill="#000000" />
              <circle cx="62" cy="49" r="4.5" fill="#fef08a" />
              <circle cx="63" cy="49" r="2" fill="#000000" />
              <path d="M 32 66 Q 50 80 68 62" stroke="#14532d" strokeWidth="4" fill="none" />
              <rect x="54" y="64" width="6" height="7" fill="#eab308" transform="rotate(-10 54 64)" />
            </>
          ) : isSalty ? (
            <>
              <line x1="30" y1="44" x2="44" y2="48" stroke="#14532d" strokeWidth="3" />
              <line x1="70" y1="44" x2="56" y2="48" stroke="#14532d" strokeWidth="3" />
              <circle cx="38" cy="50" r="3" fill="#dc2626" />
              <circle cx="62" cy="50" r="3" fill="#dc2626" />
              <path d="M 34 70 Q 50 64 66 70" stroke="#14532d" strokeWidth="3.5" fill="none" />
            </>
          ) : (
            <>
              <circle cx="38" cy="49" r="4.5" fill="#fef08a" />
              <circle cx="39" cy="49" r="2.5" fill="#0f172a" />
              <circle cx="62" cy="49" r="4.5" fill="#fef08a" />
              <circle cx="61" cy="49" r="2.5" fill="#0f172a" />
              <path d="M 35 68 Q 50 76 65 68" stroke="#14532d" strokeWidth="3" fill="none" />
              <rect x="48" y="68" width="5" height="5" fill="#eab308" />
            </>
          )}
          {/* Spiked collar */}
          <path d="M 30 80 L 70 80 L 68 96 L 32 96 Z" fill="#3f3f46" />
          <polygon points="35,80 38,72 41,80" fill="#a1a1aa" />
          <polygon points="48,80 50,70 52,80" fill="#a1a1aa" />
          <polygon points="59,80 62,72 65,80" fill="#a1a1aa" />
        </svg>

        {isPanic && (
          <div className="absolute top-1 right-1 bg-cyan-500 text-slate-950 rounded-full p-1 shadow-md animate-bounce">
            <Ghost className="w-3.5 h-3.5" />
          </div>
        )}
      </div>
    );
  };

  return (
    <div
      className={`relative rounded-3xl p-4 sm:p-5 transition-all duration-300 flex flex-col justify-between ${
        isReginald
          ? 'bg-gradient-to-b from-purple-950/70 via-zinc-950 to-zinc-950 border border-purple-900/50'
          : 'bg-gradient-to-b from-emerald-950/70 via-zinc-950 to-zinc-950 border border-emerald-900/50'
      } ${
        isCurrentTurn
          ? isReginald
            ? 'ring-2 ring-amber-400/80 shadow-[0_0_30px_rgba(245,158,11,0.2)]'
            : 'ring-2 ring-emerald-400/80 shadow-[0_0_30px_rgba(16,185,129,0.2)]'
          : 'opacity-90'
      } ${profile.emotion === 'terrified' ? 'ring-2 ring-cyan-400 shadow-[0_0_40px_rgba(6,182,212,0.4)]' : ''}`}
    >
      {/* Header Info */}
      <div className="flex items-center justify-between gap-3 mb-3">
        <div className="flex items-center gap-3">
          {renderAvatar()}
          <div>
            <div className="flex items-center gap-1.5 flex-wrap">
              <h3 className={`font-cinzel font-bold text-base sm:text-lg ${profile.accentColor}`}>
                {profile.name}
              </h3>
              {scoreLeader && (
                <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  <Flame className="w-3 h-3 text-amber-400 animate-pulse" /> LEAD
                </span>
              )}
            </div>
            <p className="text-xs text-zinc-400 flex items-center gap-1">
              {profile.title}
            </p>
            {/* Status Pills */}
            <div className="flex items-center gap-2 mt-1">
              <span className={`text-[11px] font-medium px-2 py-0.5 rounded-full uppercase tracking-wider ${
                profile.emotion === 'terrified'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 animate-pulse'
                  : isCurrentTurn
                  ? isReginald
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                  : 'bg-zinc-800 text-zinc-400'
              }`}>
                {profile.emotion === 'terrified'
                  ? 'GHOST PANIC!'
                  : isCurrentTurn
                  ? profile.isRolling
                    ? 'SHAKING CUP...'
                    : 'TAUNTING...'
                  : 'WATCHING FOE'}
              </span>

              {isCurrentTurn && (
                <span className="flex h-2 w-2 relative">
                  <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                    isReginald ? 'bg-amber-400' : 'bg-emerald-400'
                  }`} />
                  <span className={`relative inline-flex rounded-full h-2 w-2 ${
                    isReginald ? 'bg-amber-500' : 'bg-emerald-500'
                  }`} />
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Score & Match Counter */}
        <div className="text-right flex flex-col items-end">
          <div className="flex items-baseline gap-1">
            <span className="text-xs font-mono text-zinc-400 uppercase">SCORE</span>
            <span className={`font-mono font-extrabold text-2xl sm:text-3xl tracking-tight ${profile.accentColor}`}>
              {profile.totalScore.toLocaleString()}
            </span>
          </div>
          <div className="flex items-center gap-1 text-[11px] text-zinc-400 font-mono mt-0.5">
            <Trophy className="w-3 h-3 text-amber-400" />
            <span>{profile.matchWins} Sets Won</span>
          </div>
        </div>
      </div>

      {/* 3D Dice Felt Area */}
      <div className="relative rounded-2xl p-2 sm:p-3 my-2 table-felt border border-emerald-800/40 shadow-inner min-h-[96px] flex flex-col justify-center">
        <div className="absolute top-1.5 left-2 flex items-center gap-1.5 text-[10px] uppercase font-mono tracking-wider text-emerald-200/70">
          <Sparkles className="w-2.5 h-2.5" />
          <span>Felt Tray</span>
        </div>
        <div className="absolute top-1.5 right-2 text-[10px] font-mono text-emerald-300/80">
          +{profile.lastPoints} PTS
        </div>

        <Dice3D
          dice={profile.currentRoll}
          isRolling={profile.isRolling}
          theme={profile.id}
        />

        {/* Combo Description */}
        <div className="text-center mt-1">
          <span className={`inline-block px-2.5 py-0.5 rounded-full text-xs font-semibold ${
            isReginald
              ? 'bg-purple-900/80 text-amber-200 border border-amber-400/30'
              : 'bg-emerald-900/80 text-emerald-200 border border-emerald-400/30'
          }`}>
            {profile.lastCombo}
          </span>
        </div>
      </div>

      {/* DEDICATED Live Speech Box for this Player ONLY */}
      <div className={`relative mt-2 p-3.5 rounded-2xl min-h-[90px] flex flex-col justify-between transition-all ${
        profile.emotion === 'terrified'
          ? 'bg-cyan-950/40 border border-cyan-500/50 shadow-[0_0_15px_rgba(6,182,212,0.15)]'
          : isReginald
          ? 'bg-purple-950/35 border border-purple-800/45'
          : 'bg-emerald-950/35 border border-emerald-800/45'
      }`}>
        <div className="flex items-center justify-between text-[11px] mb-1 font-mono">
          <span className={`font-bold flex items-center gap-1 ${profile.accentColor}`}>
            {isReginald ? <Skull className="w-3.5 h-3.5 text-amber-400" /> : <Flame className="w-3.5 h-3.5 text-emerald-400" />}
            {profile.name}:
          </span>
          {isStreaming && (
            <span className="inline-flex items-center gap-1 text-[10px] text-cyan-400 font-mono animate-pulse">
              <Volume2 className="w-3 h-3 text-cyan-400" /> speaking...
            </span>
          )}
        </div>

        <div className={`text-sm sm:text-base leading-relaxed break-words min-h-[44px] ${
          profile.emotion === 'terrified'
            ? 'text-cyan-200 font-medium italic'
            : isReginald
            ? 'font-serif text-amber-100'
            : 'font-sans text-emerald-100'
        }`}>
          <span id={`speech-${profile.id}`}>
            {speechText || (isCurrentTurn ? "Thinking of a foul retort..." : "Observing the roll...")}
          </span>
          <span
            id={`caret-${profile.id}`}
            className="inline-block w-2 h-4 ml-1 bg-amber-400 animate-pulse align-middle"
            style={{ display: isStreaming ? 'inline-block' : 'none' }}
          />
        </div>
      </div>
    </div>
  );
};
