import React, { useState } from 'react';
import { AIProfile, GameSettings } from '../types/game';
import { Settings, X, RotateCcw, Volume2, VolumeX, Gauge, Brain, FileText, Check } from 'lucide-react';
import { DEFAULT_REGINALD, DEFAULT_GRUNK } from '../utils/personalityDefaults';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  reginald: AIProfile;
  grunk: AIProfile;
  onUpdateReginald: (profile: AIProfile) => void;
  onUpdateGrunk: (profile: AIProfile) => void;
  settings: GameSettings;
  onUpdateSettings: (settings: GameSettings) => void;
  contextHistory: Array<{ role: string; content: string }>;
  onClearHistory: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  reginald,
  grunk,
  onUpdateReginald,
  onUpdateGrunk,
  settings,
  onUpdateSettings,
  contextHistory,
  onClearHistory,
}) => {
  const [activeTab, setActiveTab] = useState<'reginald' | 'grunk' | 'game' | 'context'>('reginald');
  const [regQuotesText, setRegQuotesText] = useState(reginald.offlineQuotes.join('\n'));
  const [grunkQuotesText, setGrunkQuotesText] = useState(grunk.offlineQuotes.join('\n'));
  const [savedNotice, setSavedNotice] = useState(false);

  if (!isOpen) return null;

  const handleSaveProfiles = () => {
    // Parse quotes by line
    const parsedRegQuotes = regQuotesText
      .split('\n')
      .map(q => q.trim())
      .filter(Boolean);
    const parsedGrunkQuotes = grunkQuotesText
      .split('\n')
      .map(q => q.trim())
      .filter(Boolean);

    onUpdateReginald({
      ...reginald,
      offlineQuotes: parsedRegQuotes.length ? parsedRegQuotes : DEFAULT_REGINALD.offlineQuotes
    });

    onUpdateGrunk({
      ...grunk,
      offlineQuotes: parsedGrunkQuotes.length ? parsedGrunkQuotes : DEFAULT_GRUNK.offlineQuotes
    });

    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 2000);
  };

  const handleResetDefaults = () => {
    if (confirm('Reset both personalities and chatter lines to default tavern setup?')) {
      onUpdateReginald({ ...DEFAULT_REGINALD, totalScore: reginald.totalScore, matchWins: reginald.matchWins });
      onUpdateGrunk({ ...DEFAULT_GRUNK, totalScore: grunk.totalScore, matchWins: grunk.matchWins });
      setRegQuotesText(DEFAULT_REGINALD.offlineQuotes.join('\n'));
      setGrunkQuotesText(DEFAULT_GRUNK.offlineQuotes.join('\n'));
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-in fade-in">
      <div className="bg-zinc-900 border border-zinc-700/80 rounded-3xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-zinc-800 flex items-center justify-between bg-zinc-950/60">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-purple-600/20 text-purple-300 border border-purple-500/30">
              <Settings className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <h2 className="font-cinzel font-bold text-lg text-white">Tavern Settings &amp; Personalities</h2>
              <p className="text-xs text-zinc-400">Configure AI prompts, offline quotes, and inspect the 16k context stream.</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleResetDefaults}
              title="Reset to defaults"
              className="p-2 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 transition-colors text-xs flex items-center gap-1"
            >
              <RotateCcw className="w-4 h-4" />
              <span className="hidden sm:inline">Reset Defaults</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-zinc-800 bg-zinc-950/40 px-4 gap-2 overflow-x-auto">
          <button
            onClick={() => setActiveTab('reginald')}
            className={`py-3 px-3 text-xs sm:text-sm font-semibold border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'reginald'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Lord Reginald (AI 1)
          </button>
          <button
            onClick={() => setActiveTab('grunk')}
            className={`py-3 px-3 text-xs sm:text-sm font-semibold border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'grunk'
                ? 'border-emerald-400 text-emerald-300'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Grunk Ironbelly (AI 2)
          </button>
          <button
            onClick={() => setActiveTab('game')}
            className={`py-3 px-3 text-xs sm:text-sm font-semibold border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'game'
                ? 'border-purple-400 text-purple-300'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Pacing &amp; Audio
          </button>
          <button
            onClick={() => setActiveTab('context')}
            className={`py-3 px-3 text-xs sm:text-sm font-semibold border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'context'
                ? 'border-cyan-400 text-cyan-300'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            16k Context Log ({contextHistory.length})
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-4">
          {/* TAB 1: REGINALD */}
          {activeTab === 'reginald' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-mono text-zinc-400">Player 1 Name</label>
                  <input
                    type="text"
                    value={reginald.name}
                    onChange={(e) => onUpdateReginald({ ...reginald, name: e.target.value })}
                    className="w-full mt-1 bg-zinc-800 text-sm rounded-xl px-3 py-2 border border-zinc-700 text-amber-200 font-serif"
                  />
                </div>
                <div>
                  <label className="text-xs font-mono text-zinc-400">Title / Descriptor</label>
                  <input
                    type="text"
                    value={reginald.title}
                    onChange={(e) => onUpdateReginald({ ...reginald, title: e.target.value })}
                    className="w-full mt-1 bg-zinc-800 text-sm rounded-xl px-3 py-2 border border-zinc-700 text-zinc-200"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-mono text-zinc-400 flex items-center justify-between">
                  <span>AI System Prompt (Instructions for Reginald)</span>
                  <span className="text-amber-400/80">Max 100 Tokens Output Target</span>
                </label>
                <textarea
                  rows={4}
                  value={reginald.systemPrompt}
                  onChange={(e) => onUpdateReginald({ ...reginald, systemPrompt: e.target.value })}
                  className="w-full mt-1 bg-zinc-800 text-xs sm:text-sm rounded-xl p-3 border border-zinc-700 text-zinc-100 font-mono leading-relaxed"
                />
              </div>

              <div>
                <label className="text-xs font-mono text-zinc-400 flex items-center justify-between">
                  <span>Default (Offline) Chatter &amp; Heckles (One per line)</span>
                  <span className="text-zinc-500">
                    {regQuotesText.split('\n').filter(Boolean).length} lines
                  </span>
                </label>
                <p className="text-[11px] text-zinc-500 mb-1">
                  These lines are randomly delivered if BYOB model is disconnected or in offline preview mode.
                </p>
                <textarea
                  rows={6}
                  value={regQuotesText}
                  onChange={(e) => setRegQuotesText(e.target.value)}
                  className="w-full bg-zinc-800 text-xs sm:text-sm rounded-xl p-3 border border-zinc-700 text-amber-100 font-mono leading-relaxed"
                />
              </div>
            </div>
          )}

          {/* TAB 2: GRUNK */}
          {activeTab === 'grunk' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-mono text-zinc-400">Player 2 Name</label>
                  <input
                    type="text"
                    value={grunk.name}
                    onChange={(e) => onUpdateGrunk({ ...grunk, name: e.target.value })}
                    className="w-full mt-1 bg-zinc-800 text-sm rounded-xl px-3 py-2 border border-zinc-700 text-emerald-200"
                  />
                </div>
                <div>
                  <label className="text-xs font-mono text-zinc-400">Title / Descriptor</label>
                  <input
                    type="text"
                    value={grunk.title}
                    onChange={(e) => onUpdateGrunk({ ...grunk, title: e.target.value })}
                    className="w-full mt-1 bg-zinc-800 text-sm rounded-xl px-3 py-2 border border-zinc-700 text-zinc-200"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-mono text-zinc-400 flex items-center justify-between">
                  <span>AI System Prompt (Instructions for Grunk)</span>
                  <span className="text-emerald-400/80">Max 100 Tokens Output Target</span>
                </label>
                <textarea
                  rows={4}
                  value={grunk.systemPrompt}
                  onChange={(e) => onUpdateGrunk({ ...grunk, systemPrompt: e.target.value })}
                  className="w-full mt-1 bg-zinc-800 text-xs sm:text-sm rounded-xl p-3 border border-zinc-700 text-zinc-100 font-mono leading-relaxed"
                />
              </div>

              <div>
                <label className="text-xs font-mono text-zinc-400 flex items-center justify-between">
                  <span>Default (Offline) Chatter &amp; Heckles (One per line)</span>
                  <span className="text-zinc-500">
                    {grunkQuotesText.split('\n').filter(Boolean).length} lines
                  </span>
                </label>
                <p className="text-[11px] text-zinc-500 mb-1">
                  Goblin slang, threats of table-chewing, and manic boasting lines.
                </p>
                <textarea
                  rows={6}
                  value={grunkQuotesText}
                  onChange={(e) => setGrunkQuotesText(e.target.value)}
                  className="w-full bg-zinc-800 text-xs sm:text-sm rounded-xl p-3 border border-zinc-700 text-emerald-100 font-mono leading-relaxed"
                />
              </div>
            </div>
          )}

          {/* TAB 3: GAME SETTINGS */}
          {activeTab === 'game' && (
            <div className="space-y-5">
              <div>
                <label className="text-xs font-mono text-zinc-400 block mb-2">Turn Speed Pacing</label>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { label: 'Fast & Furious', val: 2500, desc: 'Rapid-fire bickering' },
                    { label: 'Normal Tavern', val: 3800, desc: 'Balanced timing' },
                    { label: 'Relaxed Wit', val: 5500, desc: 'Time to read each insult' }
                  ].map((speed) => (
                    <button
                      key={speed.val}
                      onClick={() => onUpdateSettings({ ...settings, turnDelayMs: speed.val })}
                      className={`p-3 rounded-xl border text-left transition-all ${
                        settings.turnDelayMs === speed.val
                          ? 'bg-purple-600/30 border-purple-500 text-white'
                          : 'bg-zinc-800/80 border-zinc-700 text-zinc-400 hover:text-zinc-200'
                      }`}
                    >
                      <div className="font-bold text-xs">{speed.label}</div>
                      <div className="text-[11px] text-zinc-400 mt-1">{speed.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between p-3.5 rounded-xl bg-zinc-800/50 border border-zinc-700/60">
                <div className="flex items-center gap-3">
                  {settings.soundEnabled ? (
                    <Volume2 className="w-5 h-5 text-emerald-400" />
                  ) : (
                    <VolumeX className="w-5 h-5 text-zinc-500" />
                  )}
                  <div>
                    <h4 className="text-sm font-semibold text-white">Audio &amp; Dice Sound Effects</h4>
                    <p className="text-xs text-zinc-400">Synthesized dice clatter, ghost wails, and score chimes.</p>
                  </div>
                </div>
                <button
                  onClick={() => onUpdateSettings({ ...settings, soundEnabled: !settings.soundEnabled })}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                    settings.soundEnabled
                      ? 'bg-emerald-600/30 text-emerald-300 border border-emerald-500/50'
                      : 'bg-zinc-700 text-zinc-400'
                  }`}
                >
                  {settings.soundEnabled ? 'Enabled' : 'Muted'}
                </button>
              </div>

              <div className="p-3.5 rounded-xl bg-zinc-800/50 border border-zinc-700/60">
                <div className="flex items-center justify-between mb-1">
                  <h4 className="text-sm font-semibold text-white">Match Target Score</h4>
                  <span className="font-mono text-purple-300 text-xs font-bold">{settings.targetScore} PTS</span>
                </div>
                <p className="text-xs text-zinc-400 mb-3">When reached, a set win is tallied and the endless game restarts immediately.</p>
                <div className="flex gap-2">
                  {[2500, 5000, 10000].map((pts) => (
                    <button
                      key={pts}
                      onClick={() => onUpdateSettings({ ...settings, targetScore: pts })}
                      className={`px-3 py-1 rounded-lg text-xs font-mono font-bold ${
                        settings.targetScore === pts
                          ? 'bg-purple-600 text-white'
                          : 'bg-zinc-800 text-zinc-400 hover:text-zinc-200'
                      }`}
                    >
                      {pts} PTS
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: CONTEXT LOG (16k) */}
          {activeTab === 'context' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-semibold text-cyan-300 flex items-center gap-1.5">
                    <Brain className="w-4 h-4" />
                    16k Token Context Stream Buffer
                  </h4>
                  <p className="text-xs text-zinc-400">
                    Live sliding memory feeding into the BYOB chat API. Maintains complete duel lore.
                  </p>
                </div>
                <button
                  onClick={onClearHistory}
                  className="px-2.5 py-1 rounded-lg text-xs bg-red-950/60 text-red-300 border border-red-800/60 hover:bg-red-900/60"
                >
                  Clear History
                </button>
              </div>

              <div className="rounded-xl bg-zinc-950 p-3 border border-zinc-800 font-mono text-[11px] max-h-72 overflow-y-auto space-y-2">
                {contextHistory.length === 0 ? (
                  <div className="text-zinc-600 italic">No turns in buffer yet.</div>
                ) : (
                  contextHistory.map((msg, i) => (
                    <div
                      key={i}
                      className={`p-2 rounded border ${
                        msg.role === 'system'
                          ? 'bg-purple-950/30 border-purple-900/40 text-purple-200'
                          : msg.content.includes('GHOST')
                          ? 'bg-cyan-950/40 border-cyan-800/40 text-cyan-200'
                          : 'bg-zinc-900 border-zinc-800 text-zinc-300'
                      }`}
                    >
                      <span className="font-bold uppercase text-[10px] text-zinc-500 mr-2">[{msg.role}]</span>
                      <span>{msg.content}</span>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-zinc-800 bg-zinc-950/80 flex items-center justify-between">
          <div className="text-xs text-zinc-400">
            {savedNotice && (
              <span className="text-emerald-400 flex items-center gap-1 animate-in fade-in">
                <Check className="w-4 h-4" /> Saved successfully!
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleSaveProfiles}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-purple-600 hover:bg-purple-500 text-white shadow-lg transition-all"
            >
              Save Changes
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
