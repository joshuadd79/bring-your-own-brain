import React from 'react';

interface Dice3DProps {
  dice: number[];
  isRolling: boolean;
  theme: 'reginald' | 'grunk';
  onDiceClick?: (index: number) => void;
}

export const Dice3D: React.FC<Dice3DProps> = ({ dice, isRolling, theme }) => {
  // Return face rotation class based on current die value (1-6)
  const getFaceClass = (val: number) => {
    switch (val) {
      case 1: return 'show-1';
      case 2: return 'show-2';
      case 3: return 'show-3';
      case 4: return 'show-4';
      case 5: return 'show-5';
      case 6: return 'show-6';
      default: return 'show-1';
    }
  };

  const isReginald = theme === 'reginald';

  // Bone ivory theme for Reginald vs Toxic mossy bone for Grunk
  const cubeBg = isReginald
    ? 'bg-gradient-to-br from-amber-50 via-amber-100 to-amber-200 text-amber-950 border border-amber-300/80 shadow-md'
    : 'bg-gradient-to-br from-zinc-800 via-emerald-950 to-zinc-900 text-emerald-300 border border-emerald-600/60 shadow-md';

  const pipColor = isReginald ? 'bg-amber-950' : 'bg-emerald-400 shadow-emerald-500/50 shadow-sm';
  const specialPip = isReginald ? 'bg-red-700' : 'bg-amber-400';

  return (
    <div className="flex flex-wrap items-center justify-center gap-3 sm:gap-4 py-2 px-1">
      {dice.map((dieValue, index) => {
        const rotationClass = isRolling ? 'rolling' : getFaceClass(dieValue);
        // Add random stagger to each die during roll
        const delayStyle = isRolling
          ? { animationDelay: `${index * 0.12}s`, animationDuration: `${0.6 + (index % 3) * 0.1}s` }
          : {};

        return (
          <div key={index} className="dice-scene select-none group cursor-pointer" title={`Die #${index + 1}: ${dieValue}`}>
            <div
              className={`dice-cube ${rotationClass}`}
              style={delayStyle}
            >
              {/* FACE 1 (Front) */}
              <div className={`dice-face face-1 ${cubeBg}`}>
                <div className="flex items-center justify-center w-full h-full">
                  <span className={`pip ${specialPip} w-3 h-3`} />
                </div>
              </div>

              {/* FACE 2 (Back) */}
              <div className={`dice-face face-2 ${cubeBg}`}>
                <div className="flex justify-between w-full h-full flex-col">
                  <div className="flex justify-end"><span className={`pip ${pipColor}`} /></div>
                  <div className="flex justify-start"><span className={`pip ${pipColor}`} /></div>
                </div>
              </div>

              {/* FACE 3 (Right) */}
              <div className={`dice-face face-3 ${cubeBg}`}>
                <div className="flex justify-between w-full h-full flex-col">
                  <div className="flex justify-end"><span className={`pip ${pipColor}`} /></div>
                  <div className="flex justify-center"><span className={`pip ${pipColor}`} /></div>
                  <div className="flex justify-start"><span className={`pip ${pipColor}`} /></div>
                </div>
              </div>

              {/* FACE 4 (Left) */}
              <div className={`dice-face face-4 ${cubeBg}`}>
                <div className="flex justify-between w-full h-full flex-col">
                  <div className="flex justify-between">
                    <span className={`pip ${pipColor}`} />
                    <span className={`pip ${pipColor}`} />
                  </div>
                  <div className="flex justify-between">
                    <span className={`pip ${pipColor}`} />
                    <span className={`pip ${pipColor}`} />
                  </div>
                </div>
              </div>

              {/* FACE 5 (Top) */}
              <div className={`dice-face face-5 ${cubeBg}`}>
                <div className="flex justify-between w-full h-full flex-col">
                  <div className="flex justify-between">
                    <span className={`pip ${pipColor}`} />
                    <span className={`pip ${pipColor}`} />
                  </div>
                  <div className="flex justify-center">
                    <span className={`pip ${pipColor}`} />
                  </div>
                  <div className="flex justify-between">
                    <span className={`pip ${pipColor}`} />
                    <span className={`pip ${pipColor}`} />
                  </div>
                </div>
              </div>

              {/* FACE 6 (Bottom) */}
              <div className={`dice-face face-6 ${cubeBg}`}>
                <div className="flex justify-between w-full h-full flex-col">
                  <div className="flex justify-between">
                    <span className={`pip ${specialPip}`} />
                    <span className={`pip ${specialPip}`} />
                  </div>
                  <div className="flex justify-between">
                    <span className={`pip ${specialPip}`} />
                    <span className={`pip ${specialPip}`} />
                  </div>
                  <div className="flex justify-between">
                    <span className={`pip ${specialPip}`} />
                    <span className={`pip ${specialPip}`} />
                  </div>
                </div>
              </div>
            </div>
            
            {/* Pip number badge below on mobile/desktop */}
            <div className="mt-2 text-center">
              <span className={`inline-block px-1.5 py-0.5 rounded text-[11px] font-mono font-bold transition-all ${
                isRolling ? 'opacity-30' : 'opacity-90'
              } ${isReginald ? 'bg-amber-950/60 text-amber-200 border border-amber-800/40' : 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/40'}`}>
                {isRolling ? '?' : dieValue}
              </span>
            </div>
          </div>
        );
      })}
    </div>
  );
};
