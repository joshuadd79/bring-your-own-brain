import React from 'react';
import { Dices, Sparkles, Settings as SettingsIcon, Play, Pause } from 'lucide-react';
import { BYOBStateInfo } from '../types/game';

interface BYOBConnectBarProps {
  byobState: BYOBStateInfo;
  isSimulatingOffline: boolean;
  onToggleOfflineSimulation: () => void;
  onOpenSettings: () => void;
  isGameRunning: boolean;
  onToggleGame: () => void;
}

export const BYOBConnectBar: React.FC<BYOBConnectBarProps> = ({
  byobState,
  isSimulatingOffline,
  onToggleOfflineSimulation,
  onOpenSettings,
  isGameRunning,
  onToggleGame,
}) => {
  const isConnected = byobState.status === 'connected';
  const isReady = isConnected || isSimulatingOffline;

  return (
    <header className="relative z-30 w-full bg-zinc-950/95 backdrop-blur border-b border-zinc-800/80 px-3 py-2 sm:px-6">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Left: Branding & Game State */}
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-purple-900/40 text-purple-300 border border-purple-500/30 flex items-center justify-center">
            <Dices className="w-5 h-5 text-amber-400" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="font-cinzel font-black text-sm sm:text-base tracking-wider bg-gradient-to-r from-amber-300 via-purple-300 to-emerald-300 bg-clip-text text-transparent">
                BONE &amp; BRAIN: THE ENDLESS DUEL
              </h1>
              {isConnected ? (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  LOCAL AI LIVE
                </span>
              ) : isSimulatingOffline ? (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  PRESET CHATTER MODE
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono bg-zinc-800 text-zinc-400 border border-zinc-700 animate-pulse">
                  CONNECT BRAIN AT RIGHT
                </span>
              )}
            </div>
            <div className="text-[11px] text-zinc-400 font-mono">
              16k Token Rich History • 100 Token Punchy Outputs
            </div>
          </div>
        </div>

        {/* Right: Connect Mount & Actions */}
        <div className="flex items-center gap-2 sm:gap-3 flex-wrap justify-center">
          {/* Action Button: Start / Pause */}
          <button
            onClick={onToggleGame}
            disabled={!isReady}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold font-mono transition-all flex items-center gap-1.5 border shadow-sm ${
              !isReady
                ? 'bg-zinc-800/50 text-zinc-500 border-zinc-800 cursor-not-allowed'
                : isGameRunning
                ? 'bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border-zinc-700'
                : 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white border-emerald-500 animate-pulse'
            }`}
          >
            {isGameRunning ? (
              <>
                <Pause className="w-3.5 h-3.5" />
                <span>PAUSE DUEL</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5" />
                <span>START DUEL</span>
              </>
            )}
          </button>

          {/* BYOB SDK Button Mount (Clean, standard topbar mount) */}
          <div
            id="byob-mount"
            className="min-w-[210px] h-[44px] flex items-center justify-center overflow-visible relative z-30"
          >
            {/* The BYOB Web SDK mounts directly here */}
          </div>

          {/* Offline fallback button if disconnected */}
          {!isConnected && (
            <button
              onClick={onToggleOfflineSimulation}
              title="Test chatter without local GPU model"
              className={`px-2.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1 transition-all border ${
                isSimulatingOffline
                  ? 'bg-amber-600/30 text-amber-200 border-amber-500/50'
                  : 'bg-zinc-800 text-zinc-400 border-zinc-700 hover:text-zinc-200'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">{isSimulatingOffline ? 'Preset Active' : 'Offline Mode'}</span>
            </button>
          )}

          <button
            onClick={onOpenSettings}
            title="Settings & Personalities"
            className="p-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-zinc-700 transition-colors"
          >
            <SettingsIcon className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
