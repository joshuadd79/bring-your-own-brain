import { AIProfile } from '../types/game';

export const DEFAULT_REGINALD: AIProfile = {
  id: 'reginald',
  name: 'Lord Reginald von Clack',
  title: 'Aristocratic Necro-Gambler',
  avatar: 'reginald',
  themeColor: 'from-amber-600 via-purple-900 to-indigo-950',
  accentColor: 'text-amber-300',
  borderColor: 'border-amber-500/50',
  systemPrompt: `You are Lord Reginald von Clack, an arrogant Victorian necromancer playing a dice duel against Grunk the goblin.
You must reply with ONLY a JSON object and nothing else:
{"line":"Your 1 short sentence insulting Grunk"}`,
  offlineQuotes: [
    "Behold, you unwashed toad! The dice dance only for nobility!",
    "Is that a roll or did a diseased pigeon expire upon the felt?",
    "I have witnessed more poise from a decapitated cockatrice!",
    "My grandmother's urn could roll a tighter full house, Grunk!",
    "By the Duke's monocle, you call those numbers?!"
  ],
  ghostQuotes: [
    "SWEET MERCIFUL HEAVENS! HIDE THE SILVER!",
    "Agh! Be gone, disembodied specter!",
    "Penelope?! I burned our prenuptial agreement!"
  ],
  totalScore: 0,
  matchWins: 0,
  currentRoll: [1, 2, 3, 4, 5],
  lastCombo: 'The Royal High Ladder',
  lastPoints: 1200,
  isRolling: false,
  emotion: 'normal'
};

export const DEFAULT_GRUNK: AIProfile = {
  id: 'grunk',
  name: 'Grunk "The Jaw" Ironbelly',
  title: 'Tavern Goblin Dice Fiend',
  avatar: 'grunk',
  themeColor: 'from-emerald-700 via-teal-950 to-zinc-950',
  accentColor: 'text-emerald-400',
  borderColor: 'border-emerald-500/50',
  systemPrompt: `You are Grunk Ironbelly, a loud goblin playing dice against Lord Reginald von Clack.
You must reply with ONLY a JSON object and nothing else:
{"line":"Your 1 short sentence mocking Reginald"}`,
  offlineQuotes: [
    "YAHA! Dem bones clattered sweet like crunchy beetle shells!",
    "Look at fancy boy crying into his lace napkin, Reginald!",
    "Them dice are loaded, wig-man!",
    "Grunk gonna chew the table legs if you keep whining!"
  ],
  ghostQuotes: [
    "WAAAAAGH! THE WALLS ARE TALKING!",
    "EEEEEK! SPIDER SPIRIT! Eat Reginald first!",
    "BOG-MOTHER SPARE ME!"
  ],
  totalScore: 0,
  matchWins: 0,
  currentRoll: [6, 6, 4, 4, 2],
  lastCombo: 'Twin Skulls (6s & 4s)',
  lastPoints: 530,
  isRolling: false,
  emotion: 'normal'
};

export const GHOST_QUICK_PHRASES = [
  "YOUR ROLLS ARE CURSED.",
  "GRUNK... LOOK BEHIND YOU.",
  "REGINALD, YOUR WIG IS ROTTING.",
  "WHOEVER LOSES SURRENDERS THEIR SOUL!"
];
