import { DiceScoreResult } from '../types/game';

export function rollFiveDice(): number[] {
  return Array.from({ length: 5 }, () => Math.floor(Math.random() * 6) + 1);
}

export function evaluateDice(dice: number[]): DiceScoreResult {
  const counts: Record<number, number> = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0 };
  let sum = 0;
  for (const d of dice) {
    counts[d] = (counts[d] || 0) + 1;
    sum += d;
  }

  const values = Object.values(counts);
  const sorted = [...dice].sort((a, b) => a - b);
  const sortedStr = sorted.join('');

  // 1. Five of a Kind
  if (values.includes(5)) {
    const val = Number(Object.keys(counts).find(k => counts[Number(k)] === 5));
    return {
      dice,
      score: 5000,
      category: 'five_kind',
      comboName: `The Archfiend's Pentagon (${val}s)`,
      description: `All five dice landed on ${val}! A celestial statistical anomaly!`,
      flavor: `By the gods! Five identical bones! The cosmos bends before this roll!`
    };
  }

  // 2. Four of a Kind
  if (values.includes(4)) {
    const val = Number(Object.keys(counts).find(k => counts[Number(k)] === 4));
    return {
      dice,
      score: 2500,
      category: 'four_kind',
      comboName: `Catastrophic Quartet (${val}s)`,
      description: `Four ${val}s staring into your adversary's soul.`,
      flavor: `Four of a kind! A devastating blow to the opponent's fragile dignity!`
    };
  }

  // 3. Full House (3 of one, 2 of another)
  if (values.includes(3) && values.includes(2)) {
    const triple = Number(Object.keys(counts).find(k => counts[Number(k)] === 3));
    const pair = Number(Object.keys(counts).find(k => counts[Number(k)] === 2));
    return {
      dice,
      score: 1500,
      category: 'full_house',
      comboName: `Haunted Crypt (Full House ${triple}s & ${pair}s)`,
      description: `Three ${triple}s and a pair of ${pair}s! Solid masonry.`,
      flavor: `A balanced monstrosity! Fortress of bone!`
    };
  }

  // 4. Large Straight
  if (sortedStr === '12345' || sortedStr === '23456') {
    return {
      dice,
      score: 1200,
      category: 'straight',
      comboName: sortedStr === '12345' ? 'The Low Dragon Run (1-5)' : 'The Royal High Ladder (2-6)',
      description: `A pristine consecutive sequence of five dice!`,
      flavor: `Smooth as polished skull-ivory! The perfect sequential alignment!`
    };
  }

  // 5. Three of a Kind
  if (values.includes(3)) {
    const val = Number(Object.keys(counts).find(k => counts[Number(k)] === 3));
    return {
      dice,
      score: 800 + sum * 5,
      category: 'three_kind',
      comboName: `Unholy Trinity (${val}s)`,
      description: `Three matching ${val}s accompanied by random refuse.`,
      flavor: `A respectable triad! The dice gods nod in grudging approval.`
    };
  }

  // 6. Two Pair
  if (values.filter(v => v === 2).length === 2) {
    const pairs = Object.keys(counts).filter(k => counts[Number(k)] === 2).map(Number);
    return {
      dice,
      score: 450 + sum * 4,
      category: 'two_pair',
      comboName: `Twin Skulls (${pairs[0]}s & ${pairs[1]}s)`,
      description: `Two distinct pairs! Double trouble or double mediocrity?`,
      flavor: `Two pairs! Symmetry for those with small imaginations.`
    };
  }

  // 7. Snake Eyes (Pair of 1s specifically)
  if (counts[1] >= 2) {
    return {
      dice,
      score: 300 + sum * 3,
      category: 'snake_eyes',
      comboName: `Snake Eyes of Despair (Pair of 1s)`,
      description: `The infamous reptilian gaze of shame!`,
      flavor: `Hissing from the shadows! A pair of ones to mock your hubris.`
    };
  }

  // 8. Boxcars (Pair of 6s specifically)
  if (counts[6] >= 2) {
    return {
      dice,
      score: 400 + sum * 3,
      category: 'boxcars',
      comboName: `Brimstone Freight (Pair of 6s)`,
      description: `Heavy iron 6s thundering down the table!`,
      flavor: `Hefty clatter of max-pip timber! Pure brute force!`
    };
  }

  // 9. Single Pair
  if (values.includes(2)) {
    const pairVal = Number(Object.keys(counts).find(k => counts[Number(k)] === 2));
    return {
      dice,
      score: 200 + sum * 2,
      category: 'one_pair',
      comboName: `Limping Crutch (Pair of ${pairVal}s)`,
      description: `Just a measly pair of ${pairVal}s.`,
      flavor: `Is that all your wrist could muster? A timid little pair!`
    };
  }

  // 10. High Sum / Scraps
  return {
    dice,
    score: 100 + sum * 3,
    category: 'high_sum',
    comboName: `Bag of Broken Teeth (Sum ${sum})`,
    description: `Complete chaotic garbage, yet still worth ${sum} raw bone pips.`,
    flavor: `No combo whatsoever! Just loose gravel tossed across velvet.`
  };
}
