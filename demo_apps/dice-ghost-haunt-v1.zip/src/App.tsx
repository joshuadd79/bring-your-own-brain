/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import confetti from 'canvas-confetti';
import {
  AIProfile,
  ChatMessage,
  GameSettings,
  BYOBStateInfo,
  DiceScoreResult,
  AIEmotion
} from './types/game';
import {
  DEFAULT_REGINALD,
  DEFAULT_GRUNK,
} from './utils/personalityDefaults';
import { rollFiveDice, evaluateDice } from './utils/diceScorer';
import { soundEngine } from './utils/audio';
import { AIPlayerCard } from './components/AIPlayerCard';
import { GhostIntercom } from './components/GhostIntercom';
import { BYOBConnectBar } from './components/BYOBConnectBar';
import { SettingsModal } from './components/SettingsModal';
import {
  Play,
  RotateCcw,
  Ghost,
  MessageSquare,
  Dices,
  Volume2,
  VolumeX,
} from 'lucide-react';

interface BYOBInstance {
  mount: () => void;
  onChunk?: (token: unknown) => void;
  chat: (
    messages: Array<{ role: string; content: string }>,
    options?: { max_tokens?: number; temperature?: number }
  ) => Promise<unknown>;
}

function tokText(t: unknown): string {
  if (typeof t === 'string') return t;
  const obj = t as Record<string, unknown> | null;
  if (!obj) return '';
  return (
    (obj.content as string) ||
    (obj.text as string) ||
    (obj.token as string) ||
    ((obj.choices as Array<{ delta?: { content?: string }; message?: { content?: string } }>)?.[0]?.delta?.content) ||
    ((obj.choices as Array<{ delta?: { content?: string }; message?: { content?: string } }>)?.[0]?.message?.content) ||
    ''
  );
}

function replyText(r: unknown): string {
  if (typeof r === 'string') return r;
  const obj = r as Record<string, unknown> | null;
  if (!obj) return '';
  return (
    (obj.content as string) ||
    (obj.text as string) ||
    ((obj.message as { content?: string })?.content) ||
    ((obj.choices as Array<{ message?: { content?: string } }>)?.[0]?.message?.content) ||
    ''
  );
}

// Strip any labels, prompt echoes, brackets, and math gibberish
function cleanDialogue(raw: string): string {
  let s = String(raw || '');
  s = s.replace(/\[Round\s*\d+\][^\n:.!]*[:.!]?/gi, '');
  s = s.replace(/^(Lord Reginald|Reginald|Grunk Ironbelly|Grunk|AI|Narrator)\s*:\s*/gi, '');
  s = s.replace(/^(\*\*.*?\*\*|\*.*?\*|["'\s]*)(says|replies|exclaims|mutters|shouts)?\s*[:,-]?\s*/gi, '');
  s = s.replace(/^(Sure|Certainly|Here is my response|As Reginald|As Grunk|My response is|I am pleased|I really enjoyed|You,? the goblin|Here's how|First off|It seems like)[^:.!]*[:.!]?\s*/gi, '');
  s = s.replace(/^\[.*?\]\s*/g, '');
  s = s.replace(/^["'“”`]+|["'“”`]+$/g, '');
  s = s.replace(/\\n/g, ' ').replace(/\s+/g, ' ').trim();

  // If text has assistant fluff at start, strip until first capitalized insult sentence
  s = s.replace(/^.*?(?:Here's how|First off|As an AI|I'm here to help)[^.!?]*[.!?]\s*/i, '');

  // Keep up to first 1 or 2 sentences max
  const sentences = s.match(/[^.!?]+[.!?]+/g);
  if (sentences && sentences.length > 0) {
    s = sentences.slice(0, 2).join(' ').trim();
  }
  return s;
}

export default function App() {
  const [reginald, setReginald] = useState<AIProfile>(DEFAULT_REGINALD);
  const [grunk, setGrunk] = useState<AIProfile>(DEFAULT_GRUNK);

  // Dedicated speech displays for each player
  const [reginaldSpeech, setReginaldSpeech] = useState<string>("Prepare yourself, swamp creature! The ivory bones will show no mercy!");
  const [grunkSpeech, setGrunkSpeech] = useState<string>("Grunk's lucky thumb is ready! Roll 'em, soft hands!");

  // Streaming speaker indicator
  const [activeSpeaker, setActiveSpeaker] = useState<'reginald' | 'grunk' | null>(null);

  // Game control: Dice play continuously without pausing for the AI!
  const [currentTurn, setCurrentTurn] = useState<'reginald' | 'grunk'>('reginald');
  const [roundNumber, setRoundNumber] = useState(1);
  const [isGameRunning, setIsGameRunning] = useState(false);

  // BYOB Web SDK state
  const [byobState, setByobState] = useState<BYOBStateInfo>({ status: 'disconnected' });
  const [isSimulatingOffline, setIsSimulatingOffline] = useState(false);
  const brainRef = useRef<BYOBInstance | null>(null);

  // Settings
  const [settings, setSettings] = useState<GameSettings>({
    turnDelayMs: 2200,
    soundEnabled: true,
    targetScore: 5000,
    temperature: 0.85,
    allowOfflineFallback: false
  });
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  // Ghost Event
  const [pendingGhostMessage, setPendingGhostMessage] = useState<string | null>(null);
  const [ghostAlert, setGhostAlert] = useState<string | null>(null);
  const [isGhostShockActive, setIsGhostShockActive] = useState(false);

  // Chat Chronicle Log
  const [chatLog, setChatLog] = useState<ChatMessage[]>([
    {
      id: 'init-1',
      sender: 'narrator',
      senderName: 'Tavern Keeper',
      content: 'The dice clatter continuously across the emerald felt as two old rivals bicker endlessly.',
      timestamp: Date.now()
    }
  ]);
  const [contextHistory, setContextHistory] = useState<Array<{ role: string; content: string }>>([]);

  // Smooth Typewriter Engine (single queue that streams character-by-character)
  const typerRef = useRef<{
    speaker: 'reginald' | 'grunk' | null;
    shown: string;
    target: string;
    running: boolean;
    waiters: Array<() => void>;
  }>({
    speaker: null,
    shown: '',
    target: '',
    running: false,
    waiters: []
  });

  const tickTypewriter = useCallback(() => {
    const t = typerRef.current;
    if (!t.speaker) {
      t.running = false;
      return;
    }

    if (t.shown.length < t.target.length) {
      const lag = t.target.length - t.shown.length;
      t.shown = t.target.slice(0, t.shown.length + (lag > 25 ? 2 : 1));

      // Direct zero-lag DOM text update without triggering heavy React component tree re-renders!
      const el = document.getElementById(`speech-${t.speaker}`);
      if (el) el.textContent = t.shown;

      const caret = document.getElementById(`caret-${t.speaker}`);
      if (caret) caret.style.display = 'inline-block';

      // Non-blocking smooth setTimeout(1) typing
      setTimeout(tickTypewriter, 1);
    } else {
      t.running = false;
      const caret = document.getElementById(`caret-${t.speaker}`);
      if (caret) caret.style.display = 'none';

      // Sync React state once when complete
      const finalSpeaker = t.speaker;
      const finalText = t.shown;
      setTimeout(() => {
        if (finalSpeaker === 'reginald') {
          setReginaldSpeech(finalText);
        } else {
          setGrunkSpeech(finalText);
        }
      }, 1);

      t.waiters.splice(0).forEach(cb => cb());
    }
  }, []);

  const typeTo = useCallback((speaker: 'reginald' | 'grunk', fullText: string) => {
    const t = typerRef.current;
    if (t.speaker !== speaker || !fullText.startsWith(t.shown)) {
      t.shown = '';
    }
    t.speaker = speaker;
    t.target = fullText;
    if (!t.running) {
      t.running = true;
      setTimeout(tickTypewriter, 1);
    }
  }, [tickTypewriter]);

  const typerDone = useCallback((): Promise<void> => {
    const t = typerRef.current;
    return t.running ? new Promise(resolve => t.waiters.push(resolve)) : Promise.resolve();
  }, []);

  // Precooking state & refs
  const isCookingRef = useRef(false);
  const lastDialogueRef = useRef<{ speaker: 'reginald' | 'grunk'; text: string }>({
    speaker: 'reginald',
    text: "Prepare yourself, swamp creature! The ivory bones will show no mercy!"
  });

  const stateRef = useRef({
    reginald,
    grunk,
    currentTurn,
    roundNumber,
    isGameRunning,
    settings,
    byobState,
    isSimulatingOffline,
    pendingGhostMessage,
    contextHistory
  });

  useEffect(() => {
    stateRef.current = {
      reginald,
      grunk,
      currentTurn,
      roundNumber,
      isGameRunning,
      settings,
      byobState,
      isSimulatingOffline,
      pendingGhostMessage,
      contextHistory
    };
    soundEngine.enabled = settings.soundEnabled;
  }, [reginald, grunk, currentTurn, roundNumber, isGameRunning, settings, byobState, isSimulatingOffline, pendingGhostMessage, contextHistory]);

  // Mount BYOB Web SDK directly to #byob-mount
  useEffect(() => {
    const handleGlobalMessage = (e: MessageEvent) => {
      const d = e.data || {};
      if (d && d.type === 'BYOB_STATE') {
        const stateStr = String(d.state || '').toLowerCase();
        if (stateStr === 'ready' || stateStr === 'connected') {
          setByobState({ status: 'connected', info: 'Local AI Connected' });
          setIsGameRunning(true);
        }
      }
    };
    window.addEventListener('message', handleGlobalMessage);

    const initBrain = () => {
      const win = window as unknown as { BringYourOwnBrainWeb?: new (opts: unknown) => BYOBInstance };
      const container = document.getElementById('byob-mount');

      if (win.BringYourOwnBrainWeb && container && !brainRef.current) {
        try {
          const brain = new win.BringYourOwnBrainWeb({
            container,
            width: '210px',
            height: '44px',
            onState: (state: unknown) => {
              const s = String(state || '').toLowerCase();
              if (s === 'ready' || s === 'connected') {
                setByobState({ status: 'connected', info: 'Local AI Connected' });
                setIsGameRunning(true);
              }
            }
          });
          brain.mount();
          brainRef.current = brain;

          if (typeof (brain as unknown as { connect?: () => Promise<unknown> }).connect === 'function') {
            (brain as unknown as { connect: () => Promise<unknown> }).connect()
              .then(() => {
                setByobState({ status: 'connected', info: 'Local AI Connected' });
                setIsGameRunning(true);
              })
              .catch(() => {});
          }
        } catch (err) {
          console.error('BYOB mount error:', err);
        }
      }

      const currentBrain = brainRef.current as unknown as { state?: string; class?: unknown };
      if (currentBrain) {
        const bState = String(currentBrain.state || '').toLowerCase();
        if (bState === 'ready' || bState === 'connected' || Boolean(currentBrain.class)) {
          setByobState({ status: 'connected', info: 'Local AI Connected' });
          setIsGameRunning(true);
        }
      }
    };

    const interval = setInterval(initBrain, 150);
    return () => {
      window.removeEventListener('message', handleGlobalMessage);
      clearInterval(interval);
    };
  }, []);

  // Precooking Engine: Precooks responses in the background while the dice keep rolling!
  const cookNextRetort = useCallback(async (forcedGhostMessage?: string) => {
    if (isCookingRef.current) return;
    const current = stateRef.current;
    const isConnected = current.byobState.status === 'connected';
    if (!isConnected && !current.isSimulatingOffline) return;

    isCookingRef.current = true;

    // The respondent is the opposite of who spoke last
    const lastSpeaker = lastDialogueRef.current.speaker;
    const respondentId: 'reginald' | 'grunk' = lastSpeaker === 'reginald' ? 'grunk' : 'reginald';
    const isReginald = respondentId === 'reginald';
    const respondentProfile = isReginald ? current.reginald : current.grunk;
    const opponentProfile = isReginald ? current.grunk : current.reginald;

    const ghostSpoke = forcedGhostMessage || current.pendingGhostMessage;

    try {
      let cookedText = '';

      if (isConnected && brainRef.current) {
        const userPrompt = ghostSpoke
          ? `You are ${respondentProfile.name}. A ghost shrieks: "${ghostSpoke}"! Reply with ONLY JSON: {"line":"Your short panic sentence"}`
          : `You are ${respondentProfile.name}. Your opponent ${opponentProfile.name} said: "${lastDialogueRef.current.text}". Reply with ONLY JSON: {"line":"Your short insult to them"}`;

        const messages = [
          { role: 'system', content: respondentProfile.systemPrompt },
          { role: 'user', content: userPrompt }
        ];

        let streamed = '';
        brainRef.current.onChunk = (tok: unknown) => {
          const t = tokText(tok);
          if (!t) return;
          if (streamed && t.length > streamed.length && t.startsWith(streamed)) {
            streamed = t;
          } else {
            streamed += t;
          }
        };

        const rawReply = await brainRef.current.chat(messages, {
          max_tokens: 60,
          temperature: settings.temperature
        });

        const fullResp = replyText(rawReply) || streamed;
        try {
          const a = fullResp.indexOf('{'), b = fullResp.lastIndexOf('}');
          if (a >= 0 && b > a) {
            const parsed = JSON.parse(fullResp.slice(a, b + 1));
            if (parsed && parsed.line) {
              cookedText = cleanDialogue(parsed.line);
            }
          }
        } catch (e) {}

        if (!cookedText) {
          cookedText = cleanDialogue(fullResp);
        }
      } else {
        // Offline preview fallback
        const pool = ghostSpoke ? respondentProfile.ghostQuotes : respondentProfile.offlineQuotes;
        cookedText = pool[Math.floor(Math.random() * pool.length)];
      }

      if (!cookedText || cookedText.length < 3) {
        cookedText = isReginald
          ? "Silence, you uncouth swamp creature!"
          : "Soft hands! Grunk's gonna crush you!";
      }

      // Smoothly type out the cooked response into the respondent's speech bubble!
      typeTo(respondentId, cookedText);
      await typerDone();

      // Update last dialogue reference for the other duelist to respond to!
      lastDialogueRef.current = { speaker: respondentId, text: cookedText };

      // Update chronicle
      setChatLog(prev => [
        {
          id: `dialogue-${Date.now()}`,
          sender: respondentId,
          senderName: respondentProfile.name,
          content: cookedText,
          timestamp: Date.now()
        },
        ...prev.slice(0, 40)
      ]);

      // Update context memory
      setContextHistory(prev => [
        ...prev.slice(-30),
        { role: 'assistant', content: `${respondentProfile.name}: "${cookedText}"` }
      ]);

      if (ghostSpoke) {
        setPendingGhostMessage(null);
      }
    } catch (err) {
      console.error('Cooking error:', err);
    } finally {
      isCookingRef.current = false;
    }
  }, [settings.temperature, typeTo, typerDone]);

  // Dice Rolling Loop: Keeps playing continuously without stopping for dialogue!
  const rollDiceTurn = useCallback(async () => {
    const current = stateRef.current;
    if (!current.isGameRunning) return;

    const isConnected = current.byobState.status === 'connected';
    if (!isConnected && !current.isSimulatingOffline) return;

    const activePlayerId = current.currentTurn;
    const isReginald = activePlayerId === 'reginald';
    const activeProfile = isReginald ? current.reginald : current.grunk;

    // 1. Shaking
    if (settings.soundEnabled) soundEngine.playDiceRattle();
    if (isReginald) {
      setReginald(prev => ({ ...prev, isRolling: true, emotion: 'rolling' }));
    } else {
      setGrunk(prev => ({ ...prev, isRolling: true, emotion: 'rolling' }));
    }

    await new Promise(r => setTimeout(r, 450));

    // 2. Roll & scoring
    const rolledDice = rollFiveDice();
    const scoreResult: DiceScoreResult = evaluateDice(rolledDice);
    if (settings.soundEnabled) soundEngine.playDiceRollLand();

    const newTotalScore = activeProfile.totalScore + scoreResult.score;

    let emotion: AIEmotion = 'normal';
    if (current.pendingGhostMessage) {
      emotion = 'terrified';
    } else if (scoreResult.score >= 1200) {
      emotion = 'smug';
      if (settings.soundEnabled) soundEngine.playScoreChime(1.5);
    } else if (scoreResult.score <= 300) {
      emotion = 'salty';
    }

    if (isReginald) {
      setReginald(prev => ({
        ...prev,
        isRolling: false,
        currentRoll: rolledDice,
        lastCombo: scoreResult.comboName,
        lastPoints: scoreResult.score,
        totalScore: newTotalScore,
        emotion
      }));
    } else {
      setGrunk(prev => ({
        ...prev,
        isRolling: false,
        currentRoll: rolledDice,
        lastCombo: scoreResult.comboName,
        lastPoints: scoreResult.score,
        totalScore: newTotalScore,
        emotion
      }));
    }

    // Check Match Win
    if (newTotalScore >= settings.targetScore) {
      confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
      if (settings.soundEnabled) soundEngine.playScoreChime(2.0);

      if (isReginald) {
        setReginald(p => ({ ...p, matchWins: p.matchWins + 1, totalScore: 0, emotion: 'victorious' }));
        setGrunk(p => ({ ...p, totalScore: 0, emotion: 'salty' }));
      } else {
        setGrunk(p => ({ ...p, matchWins: p.matchWins + 1, totalScore: 0, emotion: 'victorious' }));
        setReginald(p => ({ ...p, totalScore: 0, emotion: 'salty' }));
      }

      setChatLog(prev => [
        {
          id: `win-${Date.now()}`,
          sender: 'narrator',
          senderName: 'Tavern Crowd',
          content: `🏆 ${activeProfile.name} passes ${settings.targetScore} points and claims the set!`,
          timestamp: Date.now()
        },
        ...prev
      ]);
    }

    // Flip turn to other player
    setCurrentTurn(isReginald ? 'grunk' : 'reginald');
    if (!isReginald) {
      setRoundNumber(r => r + 1);
    }

    // Trigger precooking in the background if not currently cooking!
    if (!isCookingRef.current) {
      cookNextRetort();
    }
  }, [cookNextRetort, settings.soundEnabled, settings.targetScore]);

  // Master Dice Timer: Runs continuously every 2 seconds
  useEffect(() => {
    let timeoutId: NodeJS.Timeout;

    const tick = async () => {
      const current = stateRef.current;
      const isReady = current.byobState.status === 'connected' || current.isSimulatingOffline;
      if (current.isGameRunning && isReady) {
        await rollDiceTurn();
      }
      timeoutId = setTimeout(tick, settings.turnDelayMs);
    };

    timeoutId = setTimeout(tick, 1000);
    return () => clearTimeout(timeoutId);
  }, [rollDiceTurn, settings.turnDelayMs]);

  // Handle ghost message
  const handleSendGhostMessage = (message: string) => {
    setPendingGhostMessage(message);
    setGhostAlert(message);
    setIsGhostShockActive(true);

    if (settings.soundEnabled) soundEngine.playGhostDisturbance();

    setReginald(prev => ({ ...prev, emotion: 'terrified' }));
    setGrunk(prev => ({ ...prev, emotion: 'terrified' }));

    setChatLog(prev => [
      {
        id: `ghost-${Date.now()}`,
        sender: 'ghost',
        senderName: 'Disembodied Specter',
        content: message,
        timestamp: Date.now()
      },
      ...prev
    ]);

    // Force an immediate panic cook!
    cookNextRetort(message);

    setTimeout(() => setIsGhostShockActive(false), 2400);
    setTimeout(() => setGhostAlert(null), 4000);
  };

  const handleResetMatch = () => {
    setReginald(p => ({ ...p, totalScore: 0, emotion: 'normal' }));
    setGrunk(p => ({ ...p, totalScore: 0, emotion: 'normal' }));
    setRoundNumber(1);
    setCurrentTurn('reginald');
    setReginaldSpeech("The bones are wiped clean. Prepare yourself!");
    setGrunkSpeech("Grunk's ready! Roll 'em!");
  };

  const isConnected = byobState.status === 'connected';
  const isReady = isConnected || isSimulatingOffline;

  const scoreLeader = reginald.totalScore !== grunk.totalScore
    ? reginald.totalScore > grunk.totalScore
      ? 'reginald'
      : 'grunk'
    : null;

  return (
    <div className={`min-h-screen bg-zinc-950 text-zinc-100 flex flex-col relative overflow-x-hidden ${
      isGhostShockActive ? 'ghost-flicker' : ''
    }`}>
      {/* Ghostly blue flash during spectral speech */}
      {isGhostShockActive && (
        <div className="fixed inset-0 pointer-events-none z-40 bg-gradient-to-t from-cyan-950/40 via-transparent to-purple-950/40 border-4 border-cyan-400/40 animate-pulse" />
      )}

      {/* Top Header Bar with BYOB Mount (Clean, standard topbar mount) */}
      <BYOBConnectBar
        byobState={byobState}
        isSimulatingOffline={isSimulatingOffline}
        onToggleOfflineSimulation={() => {
          setIsSimulatingOffline(!isSimulatingOffline);
          setIsGameRunning(!isSimulatingOffline);
        }}
        onOpenSettings={() => setIsSettingsOpen(true)}
        isGameRunning={isGameRunning}
        onToggleGame={() => setIsGameRunning(!isGameRunning)}
      />

      {/* Spectral Disturbance Alert Banner */}
      {ghostAlert && (
        <div className="bg-gradient-to-r from-cyan-950 via-purple-950 to-cyan-950 border-b border-cyan-500/60 py-2.5 px-4 text-center animate-in slide-in-from-top duration-300 relative z-20">
          <div className="max-w-4xl mx-auto flex items-center justify-center gap-2 text-cyan-200">
            <Ghost className="w-5 h-5 text-cyan-400 animate-bounce" />
            <span className="font-cinzel font-bold text-xs sm:text-sm tracking-wide">
              A SPECTRAL VOICE SHRIEKS:
            </span>
            <span className="font-serif italic text-white font-semibold">"{ghostAlert}"</span>
          </div>
        </div>
      )}

      {/* Main Arena */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-6 flex flex-col gap-4">
        {/* Arena Subheader & Controls */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-3 sm:px-5">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-300 border border-amber-500/20">
              <Dices className="w-6 h-6 text-amber-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-cinzel font-bold text-sm text-zinc-200 uppercase tracking-wider">
                  ROUND {roundNumber}
                </span>
                <span className="text-zinc-500">•</span>
                <span className="text-xs font-mono text-zinc-400">
                  Target: {settings.targetScore} PTS
                </span>
              </div>
              <p className="text-xs text-zinc-400">
                Endless Tavern Duel: Continuous dice rolls with live precooked banter.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {!isGameRunning && (
              <button
                onClick={() => setIsGameRunning(true)}
                disabled={!isReady}
                className="px-4 py-2 rounded-xl text-xs font-cinzel font-bold bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg transition-all flex items-center gap-1.5 disabled:opacity-40"
              >
                <Play className="w-3.5 h-3.5" />
                <span>ROLL THE BONES</span>
              </button>
            )}

            <button
              onClick={handleResetMatch}
              title="Reset scores"
              className="p-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white border border-zinc-700 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={() => setSettings(s => ({ ...s, soundEnabled: !s.soundEnabled }))}
              title={settings.soundEnabled ? 'Mute SFX' : 'Enable SFX'}
              className="p-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white border border-zinc-700 transition-colors"
            >
              {settings.soundEnabled ? <Volume2 className="w-3.5 h-3.5 text-emerald-400" /> : <VolumeX className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* Duelists Cards: Reginald VS Grunk with their OWN separate speech boxes */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6 relative">
          <AIPlayerCard
            profile={reginald}
            isCurrentTurn={currentTurn === 'reginald'}
            speechText={reginaldSpeech}
            isStreaming={activeSpeaker === 'reginald'}
            scoreLeader={scoreLeader === 'reginald'}
          />

          <AIPlayerCard
            profile={grunk}
            isCurrentTurn={currentTurn === 'grunk'}
            speechText={grunkSpeech}
            isStreaming={activeSpeaker === 'grunk'}
            scoreLeader={scoreLeader === 'grunk'}
          />
        </div>

        {/* Ghost Intercom Bar: Speak into the room */}
        <GhostIntercom
          onSendGhostMessage={handleSendGhostMessage}
          disabled={!isReady}
        />

        {/* Live Duel Chronicle */}
        <div className="rounded-2xl bg-zinc-900/70 border border-zinc-800/80 p-3 sm:p-5 flex flex-col gap-3">
          <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
            <div className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-purple-400" />
              <h3 className="font-cinzel font-bold text-sm text-zinc-200">
                THE DUEL CHRONICLE (LIVE FEED)
              </h3>
            </div>
            <span className="text-[11px] font-mono text-zinc-500">
              {chatLog.length} events logged
            </span>
          </div>

          <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
            {chatLog.map((msg) => {
              const isReg = msg.sender === 'reginald';
              const isGrunk = msg.sender === 'grunk';
              const isGhost = msg.sender === 'ghost';

              return (
                <div
                  key={msg.id}
                  className={`p-3 rounded-xl border transition-all text-xs sm:text-sm ${
                    isGhost
                      ? 'bg-cyan-950/40 border-cyan-600/50 text-cyan-200 shadow-md'
                      : isReg
                      ? 'bg-purple-950/20 border-purple-900/40 text-purple-100'
                      : isGrunk
                      ? 'bg-emerald-950/20 border-emerald-900/40 text-emerald-100'
                      : 'bg-zinc-800/40 border-zinc-700/40 text-zinc-300'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 mb-1 flex-wrap font-mono">
                    <span className={`font-bold flex items-center gap-1.5 ${
                      isGhost ? 'text-cyan-300' : isReg ? 'text-amber-300' : isGrunk ? 'text-emerald-300' : 'text-zinc-400'
                    }`}>
                      {isGhost && <Ghost className="w-3.5 h-3.5 text-cyan-400" />}
                      {msg.senderName}
                    </span>
                    {msg.diceSummary && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-zinc-900 text-zinc-300 border border-zinc-700">
                        {msg.diceSummary}
                      </span>
                    )}
                  </div>
                  <p className={`leading-relaxed ${isGhost ? 'font-serif italic text-cyan-100 font-semibold' : ''}`}>
                    {msg.content}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </main>

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        reginald={reginald}
        grunk={grunk}
        onUpdateReginald={setReginald}
        onUpdateGrunk={setGrunk}
        settings={settings}
        onUpdateSettings={setSettings}
        contextHistory={contextHistory}
        onClearHistory={() => {
          setContextHistory([]);
          setChatLog([]);
        }}
      />
    </div>
  );
}
